Is it too hard to read the letters in the Monochrome song? Well I have the solution for your visible problem. 
This replaces the alphabet this mod uses instead of the confusing drawings that make it difficult to type words fast.

--Install Instructions--
STEP 1: Download the .png file with the mediafire link provided.
STEP 2: Navigate to your mod folder, C:\Users\*USER*\Modlocation\fnf_hypnos_lullaby_v10\FNF Hypnos Lullaby v1.0\assets\shared\images
STEP 3: Replace the "Unown_Alphabet.png" file with the one you have downloaded from this mod page.
STEP 4: Enjoy! Your letters now should be replaced with new and visible ones.